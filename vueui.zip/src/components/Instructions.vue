<template>
    <p class="body-1"><strong>Instructions</strong>: {{ details }}</p>
</template>

<script>
export default {
    props: ["details"]
};
</script>
