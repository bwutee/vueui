<template>
  <v-container>
    <div>
      <h4 class="display-1">About Us</h4>

      <p class="body-1">We are a bunch of nerds.</p>
    </div>
  </v-container>
</template>
